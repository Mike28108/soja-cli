// Galería interactiva: ←/→ cambia de escena, espacio pausa, q sale.
// npx tsx examples/demo.tsx
import React, { useState } from 'react';
import { Box, Text, render, useApp, useInput } from 'ink';
import { AgentScene, SCENES, SCENE_IDS } from '../src/index.js';

function Demo() {
  const { exit } = useApp();
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const id = SCENE_IDS[i]!;

  useInput((input, key) => {
    if (key.rightArrow || input === 'l') setI((n) => (n + 1) % SCENE_IDS.length);
    if (key.leftArrow || input === 'h') setI((n) => (n - 1 + SCENE_IDS.length) % SCENE_IDS.length);
    if (input === ' ') setPaused((p) => !p);
    if (input === 'q' || key.escape) exit();
  });

  return (
    <Box flexDirection="column" paddingX={1}>
      <Box justifyContent="space-between" width={SCENES[id].width}>
        <Text bold color="#D85A30">
          {SCENES[id].title}
        </Text>
        <Text dimColor>
          {i + 1}/{SCENE_IDS.length} · {SCENES[id].useFor}
        </Text>
      </Box>
      <AgentScene key={id} scene={id} paused={paused} />
      <Text dimColor>←/→ escena · espacio {paused ? 'reanudar' : 'pausar'} · q salir</Text>
    </Box>
  );
}

render(<Demo />);
