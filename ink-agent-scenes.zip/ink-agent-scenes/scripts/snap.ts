// Uso: tsx scripts/snap.ts <sceneId> [frame1,frame2,...]
// Imprime fotogramas en texto plano para revisar la composición.
import { SCENES, type SceneId } from '../src/scenes/index.js';
import { frameToText } from '../src/ansi.js';

const id = process.argv[2] as SceneId;
const frames = (process.argv[3] ?? '0,20,60').split(',').map(Number);
const def = SCENES[id];
if (!def) {
  console.error('Escenas:', Object.keys(SCENES).join(', '));
  process.exit(1);
}
const rt = def.create(1);
let t = 0;
for (const f of frames) {
  while (t < f) {
    rt.step();
    t++;
  }
  console.log(`--- ${id} @${f} | ${rt.status()}`);
  console.log(frameToText(def, rt).split('\n').map((l) => l + '|').join('\n'));
}
