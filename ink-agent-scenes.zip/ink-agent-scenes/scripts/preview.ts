// Vista previa en la terminal sin Ink (solo ANSI).
// npx tsx scripts/preview.ts            → recorre todas las escenas
// npx tsx scripts/preview.ts fire       → solo una
import { SCENES, SCENE_IDS, type SceneId } from '../src/scenes/index.js';
import { frameToAnsi } from '../src/ansi.js';

const only = process.argv[2] as SceneId | undefined;
const ids = only ? [only] : SCENE_IDS;
const SECONDS_PER_SCENE = 8;
let idx = 0;
let def = SCENES[ids[0]!];
let rt = def.create();
let frame = 0;

process.stdout.write('\x1b[?25l');
const restore = () => {
  process.stdout.write('\x1b[?25h\n');
  process.exit(0);
};
process.on('SIGINT', restore);

setInterval(() => {
  rt.step();
  frame++;
  if (!only && frame > SECONDS_PER_SCENE * 10) {
    idx = (idx + 1) % ids.length;
    def = SCENES[ids[idx]!];
    rt = def.create();
    frame = 0;
  }
  const header = `\x1b[1m${def.title}\x1b[0m \x1b[2m· ${def.useFor} · ctrl+c para salir\x1b[0m`;
  process.stdout.write('\x1b[H\x1b[2J' + header + '\n' + frameToAnsi(def, rt) + '\n\x1b[2m' + rt.status() + '\x1b[0m');
}, 100);
