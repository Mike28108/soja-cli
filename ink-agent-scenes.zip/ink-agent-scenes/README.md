# ink-agent-scenes

Escenas ASCII animadas de mini agentes color arcilla para apps de terminal hechas con [Ink](https://github.com/vadimdemedes/ink).

```tsx
import { AgentScene } from 'ink-agent-scenes';

<AgentScene scene="working" />
```

## Escenas

| id          | Escena              | Para usar cuando…                         |
| ----------- | ------------------- | ----------------------------------------- |
| `working`   | Trabajando          | Hay tareas en progreso                    |
| `resting`   | Descansando         | No hay actividad o la app está en pausa   |
| `clockIn`   | Ponchando entrada   | Arranca el día o la app está cargando     |
| `planning`  | Analizando planes   | Planificación o revisión de sprint        |
| `fire`      | Apagando incendio   | Hay tareas urgentes o un incidente        |
| `celebrate` | Celebrando          | Se completó una tarea o una meta          |
| `syncing`   | Sincronizando       | Se están cargando o sincronizando datos   |
| `bugHunt`   | Cazando bugs        | Hubo un error o hay tareas bloqueadas     |
| `empty`     | Pescando            | La lista está vacía                       |
| `deadline`  | Contra reloj        | Hay tareas vencidas o por vencer          |
| `cleaning`  | Limpiando           | Se archivan o limpian tareas terminadas   |

Todas miden 78 columnas de ancho (entre 12 y 15 filas de alto), así que caben en una terminal de 80 columnas.

## Props

| prop         | tipo               | por defecto | descripción                                        |
| ------------ | ------------------ | ----------- | -------------------------------------------------- |
| `scene`      | `SceneId`          | —           | Escena a mostrar                                   |
| `fps`        | `number`           | `10`        | Fotogramas por segundo                             |
| `paused`     | `boolean`          | `false`     | Congela la animación                               |
| `showStatus` | `boolean`          | `true`      | Muestra la línea de estado debajo                  |
| `statusText` | `string`           | —           | Sustituye el texto de estado de la escena          |
| `palette`    | `Partial<Palette>` | —           | Cambia colores por tono, p. ej. `{ agent: '#7F77DD' }` |
| `seed`       | `number`           | —           | Misma semilla = misma animación                    |

## Estados del task manager

`TASK_STATE_SCENES` y `sceneForState()` traen un mapa sugerido de estado → escena:

```tsx
import { AgentScene, sceneForState } from 'ink-agent-scenes';

<AgentScene scene={sceneForState(tasks.length ? 'inProgress' : 'empty')} />
```

Hay un ejemplo completo en `examples/task-status.tsx`.

## Probar

```bash
npm install
npm run demo      # galería en Ink: ←/→ cambia de escena, espacio pausa, q sale
npm run preview   # vista previa sin Ink, solo ANSI
npm run build     # compila a dist/
```

`preview.html` muestra las mismas escenas en el navegador.

## Crear escenas nuevas

Una escena es un `SceneDef` con `create()`, que devuelve `step()`, `draw(canvas)` y `status()`. El motor (`src/engine.ts`) no depende de React, así que las escenas se pueden probar con `npm run snap -- <id> 0,30,60`, que imprime fotogramas en texto plano. Registra la escena nueva en `src/scenes/index.ts`.
