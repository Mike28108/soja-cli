// Ejemplo de integración: la escena sigue el estado de la lista de tareas.
import React from 'react';
import { Box, Text } from 'ink';
import { AgentScene, sceneForState, type TaskState } from '../src/index.js';

interface Task {
  title: string;
  done: boolean;
  due?: Date;
}

function stateFor(tasks: Task[], opts: { syncing: boolean; error?: string }): TaskState {
  if (opts.error) return 'error';
  if (opts.syncing) return 'syncing';
  if (tasks.length === 0) return 'empty';
  const pending = tasks.filter((t) => !t.done);
  if (pending.length === 0) return 'completed';
  if (pending.some((t) => t.due && t.due.getTime() < Date.now())) return 'overdue';
  return 'inProgress';
}

export function TaskHeader({ tasks, syncing, error }: { tasks: Task[]; syncing: boolean; error?: string }) {
  const state = stateFor(tasks, { syncing, error });
  const pending = tasks.filter((t) => !t.done).length;
  return (
    <Box flexDirection="column">
      <AgentScene scene={sceneForState(state)} statusText={error ?? `${pending} pendientes de ${tasks.length}`} />
      <Text dimColor>estado: {state}</Text>
    </Box>
  );
}
